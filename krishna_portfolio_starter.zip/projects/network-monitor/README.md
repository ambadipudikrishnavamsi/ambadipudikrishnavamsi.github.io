# Network Monitoring Tool — Python
Simple network health probe to log latency and DNS resolution results.

## Run
```bash
python src/monitor.py --host google.com --interval 30
```
