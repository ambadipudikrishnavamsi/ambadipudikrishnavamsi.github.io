import argparse, time, socket, subprocess, platform, datetime

def ping(host):
    count = '1'
    param = '-n' if platform.system().lower()=='windows' else '-c'
    cmd = ['ping', param, count, host]
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, timeout=5).decode()
        return True, out
    except Exception as e:
        return False, str(e)

def dns_lookup(host):
    try:
        return socket.gethostbyname(host)
    except socket.gaierror:
        return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', default='google.com')
    ap.add_argument('--interval', type=int, default=60, help='seconds between probes')
    args = ap.parse_args()

    while True:
        ts = datetime.datetime.utcnow().isoformat()
        ip = dns_lookup(args.host)
        ok, out = ping(args.host)
        print(f"{ts} host={args.host} ip={ip} ping_ok={ok}")
        time.sleep(args.interval)

if __name__ == '__main__':
    main()
