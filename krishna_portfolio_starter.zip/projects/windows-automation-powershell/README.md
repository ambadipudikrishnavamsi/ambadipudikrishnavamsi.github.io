# Windows System Build Automation — PowerShell
Automate workstation provisioning for consistency and speed.

## What it does
- Installs common apps (winget)
- Sets power/defender policies placeholders
- Example printer mapping and BitLocker status check

> Run PowerShell as Administrator.
