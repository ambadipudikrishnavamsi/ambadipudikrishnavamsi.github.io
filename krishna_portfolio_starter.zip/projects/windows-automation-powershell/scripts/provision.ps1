# Requires: Windows 10/11, PowerShell 5+, winget installed
Write-Host "Starting workstation provisioning..."

# Install common apps (edit as needed)
$apps = @(
  "Google.Chrome",
  "Microsoft.PowerToys",
  "Notepad++",
  "Git.Git"
)

foreach ($a in $apps) {
  Write-Host "Installing $a ..."
  winget install --id $a --silent --accept-source-agreements --accept-package-agreements
}

# Example: printer mapping (replace with your print server/share)
# Add-Printer -ConnectionName "\\print-server\HP-LaserJet-01"

# BitLocker status
Write-Host "BitLocker status:"
manage-bde -status

Write-Host "Provisioning complete."
