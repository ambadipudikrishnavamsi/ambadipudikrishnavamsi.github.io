# Dealer Performance Dashboard — SQL + Python + Power BI
Lightweight analytics stack for dealership KPIs.

## Steps
1. Place your CSVs in `data/` (sales, service, inventory).
2. Use `sql/models.sql` to create basic views in SQLite/Postgres.
3. Build a Power BI report connected to the transformed tables.
