-- Example SQL model for a sales summary view
CREATE VIEW sales_summary AS
SELECT
  salesperson,
  COUNT(*) AS deals,
  SUM(price) AS total_revenue,
  DATE(order_date) AS day
FROM sales
GROUP BY salesperson, DATE(order_date);
